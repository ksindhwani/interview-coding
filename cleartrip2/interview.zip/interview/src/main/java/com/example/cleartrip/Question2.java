package com.example.cleartrip;

/**
 * 
 * {[0,1],[0,2],[3,4],[4,5]}
 * 
 * parent Array- 
 * 
 * 0 0 0 3 3 3  - inital input
 * 
 * 
 * 
 * 5 vertices - 
 * 
 * 
 * 
 * 
 * 
 */
public class Question2 {
    
}
