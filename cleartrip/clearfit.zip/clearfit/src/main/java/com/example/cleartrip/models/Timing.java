package com.example.cleartrip.models;

public class Timing {
    int startTime;
    int EndTime;

    public Timing(int startTime, int endTime) {
        this.startTime = startTime;
        EndTime = endTime;
    }

    public int getStartTime() {
        return startTime;
    }

    public int getEndTime() {
        return EndTime;
    }
    
    
}
